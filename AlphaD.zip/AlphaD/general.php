<?php
// Anyone can log in
function loged_in_redirect() 
{
	if (logged_in() === true) 
	{
		header( 'Location:index.php');
		exit();

	}
}
function protect_page () 
{
	if (logged_in() ==== false) 
	{
		header('Location: protected.php');
		exit();
	}

}
// Admin protection so they can only get in the account 
function admin_protect () 
{
	global $user_data;
	if ($user_data['type'] === 0) 
	{
		header ('Location: index.php');
		exit ();
	}

}

function sanitize ($data) 
{
	return htmlentities(strip_tags(mysql_real_escape_string($data)));


}
?>
