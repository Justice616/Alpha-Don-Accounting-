<?php

 include_once 'dbh.inc.php';

 $userid = $_POST['userid'];
  $first = $_POST['first'];
   $last = $_POST['last'];
    $email = $_POST['email'];
     $password= $_POST['paswword'];
      $confirmpwd = $_POST['confirmpwd'];


	$sql = "INSERT INTO `SignUp` (`User ID`, `First Name`, `Last Name`, `Email`, `Password`, `Confirm Password`) VALUES
('$userid', '$first', '$last', '$email', '  $password', '$confirmpwd  '),";
	$result = mysqli_query($conn, $sql);
	
	header("Location:  ../index.php?signup=success")