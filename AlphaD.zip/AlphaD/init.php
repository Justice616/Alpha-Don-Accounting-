<php
session_start();

require 'database/connect.php'
require 'Regi.php'
t.php';
al.php';
.php';

'/', $_SERVER['SCIRPT_NAME']);
rent_file);
) {
	
	_SESSION['user_id'];
	ta($session_user_id, `User ID`, `First Name`, `Last Name`, `Email`, `Password`, `Confirm Password`);
	r_data['User ID']) === false) 
	{
	);
	:index.php');

	'changepassword.php' && $user_data['password_recover'] ==1) 
	{
	changepassword.php?force');

}

}
}


