<?php
 include_once 'includes/dbh.inc.php';
 ?>

<!DOCTYPE HTML>
<html>
<head>
	<title></title>
</head>
<body>

	<!-- Sign up form -->
	<!-- <div class= "header">
	<h2> Register </h2>
</div>
<form method="post" action= "register.php">
	<div class="input-group">
		<label>User ID</label>
		<input type="int" name= "user id">
	</div>
	<div class="input-group">
		<label>First Name</label>
		<input type="varchar" name= "first name">
	</div>
	<div class="input-group">
		<label>Last Name</label>
		<input type="varchar" name= "last name">
	</div>
	<div class="input-group">
		<label>Email</label>
		<input type="varchar" name= "Email">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="varchar" name= "password">
	</div>
<div class="input-group">
		<label>Confirm Password</label>
		<input type="varchar" name= "confirm password">
	</div>
	<div class="input-group">
	
		<input type="submit" name= "register" class "btn">Register</button>
	</div> -->
	<form action="includes/signup.inc.php" method="POST">
		<input type= "text" name="first" placeholder= "FirstName">
		<br>
		<input type= "text" name="last" placeholder= "Lastname">
		<br>
		<input type= "text" name="last" placeholder= "LastName">
		<br>
		<input type= "text" name="email" placeholder= "Email">
		<br>
		<input type= "password" name="password" placeholder= "Password">
		<br>
		<input type= "password" name="confirmpwd" placeholder= "Confirm Password">
		<br>
		<button type= "submit" name="submit" >Sign Up</button>

	</form>
<!-- Insert Names -->

	// $resultCheck = mysqli_num_rows($result);

	// if ($resultCheck > 0) {
	// 	while ($row = mysqli_fetch_assoc($result)){
	// 		echo $row['user_']
	?>

</body>
</html>





