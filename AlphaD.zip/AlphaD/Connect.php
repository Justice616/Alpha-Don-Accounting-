<?php
$db=mysqli_connect('localhost', 'root', '','SignUp') or die ($db);

$userid = filter_input(INPUT_POST,'username');
$password = filter_input(INPUT, 'password');
if(!empty($userid)){

}
if(!empty($password)){
	$host = 'localhost';
	$
}

// Database name goes above
