<!DOCTYPE html>
<html>
<head>
<title> User registration system using PHP and MYSQL</title>
<link rel="styesheet" type="text/css" href="style3.css">
</head>
<body>

<div class= "header">
	<h2> Register </h2>
</div>
<form method="post" action= "register.php">
	<div class="input-group">
		<label>User ID</label>
		<input type="int" name= "user id">
	</div>
	<div class="input-group">
		<label>First Name</label>
		<input type="text" name= "first name">
	</div>
	<div class="input-group">
		<label>Last Name</label>
		<input type="text" name= "last name">
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" name= "password">
	</div>
<div class="input-group">
		<label>Confirm Password</label>
		<input type="password" name= "confirm password">
	</div>
	<div class="input-group">
	
		<input type="submit" name= "register" class "btn">Register</button>
	</div>







</body>
</html>