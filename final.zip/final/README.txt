
 1. create database named 'journal'
 2. import 'tables.sql'
 3. change database credentials in config.php


following users added :
user1:password
user2:password
manager1:password
manager2:password
admin1:password
