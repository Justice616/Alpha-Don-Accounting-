/* modify this file */

var accounts = [
	'Cash',
	'Owners Equity',
	'Accounts Receivable',
	'Inventory',
	'Accounts Payable',
	'Service Revenue',
];
