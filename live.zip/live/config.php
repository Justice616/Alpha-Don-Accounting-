<?php

$mysql_servername = "localhost";
$mysql_username = "root";
$mysql_password = "";

$mysql_database = "journal";
