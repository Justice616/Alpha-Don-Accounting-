
 1. change database credentials in config.php
 2. run setup.php

following users added :
user1:password
user2:password
manager1:password
manager2:password
admin1:password
